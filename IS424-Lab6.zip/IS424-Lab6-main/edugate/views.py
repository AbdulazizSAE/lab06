from django.shortcuts import render, redirect
from .models import Student, Course
from django.http import HttpResponseRedirect
from django.urls import reverse

# Create your views here.

def index(request):
    return render(request, "edugate/index.html")

def students(request):
    if request.method == "POST":
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        student_id = request.POST.get('student_id')

        student = Student(fname, lname, student_id)
        student.save()

        selected_courses = request.POST.getlist('courses')
        for course_code in selected_courses:
            course = Course.objects.get(code=course_code)
            student.courses.add(course)

        return HttpResponseRedirect(reverse('students'))
    else:
        students_list = Student.objects.all()
        courses_list = Course.objects.all()
        return render(request, "edugate/students.html", {
            "students": students_list,
            "courses": courses_list
            })
    
def courses(request):
    if request.method == "POST":
        name = request.POST.get('name')
        code = request.POST.get('code')

        course = Course(name, code)
        course.save()

        return HttpResponseRedirect(reverse('courses'))
    else:
        courses_list = Course.objects.all()
        return render(request, "edugate/courses.html", {
            "courses": courses_list
        })
    
def details(request, sID):
    student = Student.objects.get(student_id=sID)
    if request.method == "POST":
        course_code = request.POST.get('course_id')
        course = Course.objects.get(code=course_code)
        student.courses.add(course)
        return HttpResponseRedirect(reverse("details", args=(student.student_id,)))
    else:
        not_reg_courses = Course.objects.exclude(students=student)
        return render(request, "edugate/details.html", {
            "student": student,
            "not_reg_courses": not_reg_courses
        })
