from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('students/', views.students, name="students"),
    path('details/<int:sID>/', views.details, name="details"),
    path('courses/', views.courses, name="courses")
]